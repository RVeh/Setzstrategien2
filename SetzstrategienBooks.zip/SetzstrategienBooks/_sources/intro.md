# Setzstrategien

Die folgenden Python-Programme sind zum Artikel 

#### Chip-Abräumspiele wie Differenz trifft - II. Gewinnwahrscheinlichkeiten mit und ohne ChatGPT 

von Norbert Henze, Karlsruhe, und Reimund Vehling, Hannover, entstanden.


**Zusammenfassung:** In diesem Aufsatz geht es um Gewinnwahrscheinlichkeiten bei Chip-Abräumspielen, zu denen insbesondere *Differenz trifft* gehört. Bei einem solchen Spiel gibt es $m$ Felder, die in unabhängigen gleichartigen Würfen mit den Wahrscheinlichkeiten $p_1, \ldots , p_m$ getroffen werden. Insgesamt sind $n$ Chips auf diese Felder zu verteilen. Spielen zwei Personen gegeneinander, so gewinnt diejenige, die zuerst alle Chips abräumen kann. Dabei kann immer ein auf einem getroffenen Feld liegender Chip entfernt werden. Es wird gezeigt, wie man Gewinnwahrscheinlichkeiten mithilfe von Rekursionsformeln erhalten kann, wobei konzeptionell nur die Pfadregeln eingehen. Es zeigt sich u.a., dass es beim Spiel *Differenz trifft* mit Ausnahme von $n = 3$ und $n = 9$ für jedes $n \leq 17$ genau eine optimale Setzstrategie gibt. Beim Spiel *Differenz trifft* wird in Schulbüchern oft der Eindruck erweckt, dass bei 18 Chips die zu den Wahrscheinlichkeiten der 6 möglichen Ausgänge proportionale Setzstrategie  optimal sei. Dieser voreilige Schluss ist jedoch falsch.


```{tableofcontents}
```
